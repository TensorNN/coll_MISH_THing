import numpy as np
import os
import copy

loc="/Users/ahauss/Desktop/net1_f/"

def rand_net(net_type,dat_size):#makes randome matrix mXn
	mat=[""]*len(net_type)
	for x in range( len(net_type)-1 ):
		mat[x]=[0]*(net_type[x]+1)
		for y in range(net_type[x]+1):
			mat[x][y]=random_mat_double(dat_size,net_type[x+1])

	return mat
	

def random_mat_double(dat_size,lanth):
	wit=[0]*lanth
	for x in range(lanth):
		wit[x]=random_mat(dat_size)
	return wit



def random_mat(x):# makes a random value
	real = (np.random.rand(x)-0.5)*10
	comp = (np.random.rand(x)-0.5)*1j*10
	out = real+comp
	return out

def stor_mat(name,loc,mat):
		f = open(loc+name+".txt", "w")
		for x in range( len(mat) ):
			for y in range( len(mat[x]) ):
				f.write(str(mat[x][y]))
				if y!=(len(mat[x])-1):
					f.write(",")
			f.write("\n")
		f.close()

def stor_net(net_type,net,loc):
	for x in range( len(net_type)-1 ):
		path = loc+"L"+str(x)
		try:
			os.mkdir(path)
		except:
			pass
		for y in range( len(net[x]) ):
			theloc=path
			name="/V"+str(y)

			stor_mat(name,theloc, net[x][y] )


def get_matrix_numbs(loc,name):
	with open(loc+name+".txt","r") as f:
		array=[""]
		for line in f:
			m=line
			m=m.strip("\n")
			m=m.split(",")
			for x in range(len(m)):

				m[x]=complex(m[x])
			array.append(m)
	f.close()
	array.pop(0)
	return array

def rand_m_n(m,n):#makes randome matrix mXn
	mat=[""]*m
	for x in range(m):
		mat[x]=random_mat(n)
	return mat
def random_mat(x):# makes a random value
	return np.random.rand(x)

def the_dot(mat,vec):
	out=[0]*len(mat[0])
	for x in range( len(vec) ):
		for y in range(len(mat[0])):
			out[y]+=mat[x][y]*vec[x]
	return out

def make_mult_matirx(rank,upper,lower):
	out=np.zeros( (rank,rank),dtype=complex )
	for x in range(rank):
		for y in range(rank):
			if (x+y)==0:
				out[x][y]=complex(upper-lower)
			else:
				#print((x+y)*(0+1j)*upper)
				out[x][y]+=np.exp((x+y)*(0+1j)*upper )/(x+y)-np.exp((x+y)*(0+1j)*lower )/(x+y)
	return out




def the_dotF(mat,vec,matrix):


	out=[0]*len(mat[0])

	for x in range( len(out)):
		out[x]=[complex(0)]*len(matrix)
	for x in range( len(vec) ):
		for y in range(len(mat[0])):

			out[y]=add_a_b(out[y] ,getH_oJI(mat[x][y],vec[x],matrix) )
	return out

def add_a_b(a,b):
	out=[0]*len(a)
	for x in range( len(a) ):
		out[x]=a[x]+b[x]
	return out

def sub_a_b(a,b):
	out=[0]*len(a)
	for x in range( len(a) ):
		out[x]=a[x]-b[x]
	return out

def getH_oJI(J,I,matrix):
	IA=np.dot(I,matrix)
	for x in range(len(IA)):
		IA[x]=IA[x]*J[x]
	return IA




def sig(x):# sigmod function 
	return 1/(1+np.exp(-x))
def sigf(func):
	out=np.fft.ifft(func)
	for x in range( len(func)):
		out[x]=sig(out[x].imag)*1j+sig(out[x].real)
	return out
#stor_net(net_ty

def get_mat_F(net_type,loc):
	netout=[0]*( len( net_type)-1 )
	for x in range( len(net_type)-1  ):
		netout[x]=[0]*net_type[x] 

	for x in range( len( net_type)-1 ):
		for y in range( net_type[x] ):
			netout[x][y]=get_matrix_numbs(loc+"L"+str(x)+"/","V"+str(y))
	return netout

def forward_F(net,imp,net_type,data_size,top,bot):
	mat=make_mult_matirx(data_size,bot,top)

	netc=copy.deepcopy(net)
	nerons=[0]*len(net_type)

	for x in range(len(net_type)):
		nerons[x]=[0]*(net_type[x]+1)
		for y in range(net_type[x]):
			nerons[x][y]=[complex(0)]*data_size

		nerons[x][net_type[x]]=[complex(1)]*data_size

	for x in range(len(imp)):
		nerons[0][x]=sigf(imp[x])

	for x in range(len(net_type)-1):
		#print(len(net[x]))
		#print(len(net[x][0]))
		#print(len(nerons[x]))

		hold=the_dotF(net[x],nerons[x],mat)

		for k in range(len(nerons[x+1])-1):

			nerons[x+1][k]=sigf(hold[k])


	return nerons




def back_ward_prop(net,output,net_type,nerds,lear_rate,data_size,top,bot):

	mat=make_mult_matirx(data_size,bot,top)

	pet=copy.deepcopy(net)

	nerons=[0]*len(net_type)
	
	for x in range(len(net_type)):
		nerons[x]=[0]*(net_type[x]+1)
		for y in range(net_type[x]):
			nerons[x][y]=[complex(0)]*data_size

		nerons[x][net_type[x]]=[complex(1)]*data_size


	for x in range( len(output) ):

		nerons[ len(nerons)-1 ][x]=output[x]


	delta=[0]*len(nerds)
	#print("somethingwrong")
	for tot in range(len(net_type)):
		hold=[0]*len(nerons[ len(nerons)-1-tot] )
		for y in range( len(nerons[ len(nerons)-1-tot] )):
			hold[y]=sub_a_b( nerons[ len(nerons)-1-tot][y],nerds[len(nerons)-1-tot][y] )
		

		delta[tot]=hold
		#print("here")
		#print(delta[tot])
		#delta[tot].pop( len(delta[tot])-1 )


		holder=copy.deepcopy(nerds[len(nerons)-2-tot])
		#print("holder1",holder)

		
		nethold=copy.deepcopy(pet[len(net)-1-tot])
		for x in range(len(nethold)):
			#print("here")
			#print(len(nethold))
			#print(len(delta[tot]))

			for z in range( len(nethold[x]) ):
				pass

				nethold[x][z]=getH_oJI( nethold[x][z], delta[tot][x], mat) 
				#print(holder)
				nethold[x][z]=getH_oJI( nethold[x][z],  holder[z] , mat )



		#print("we made it")
		print(pet[len(net)-1-tot])
		print()
		print(nethold)
		print()
		print()
		print()
		pet[len(net)-1-tot]=add_a_b( pet[len(net)-1-tot] , nethold )
	pet.pop( len(pet)-1 )
	pet.append("")
	return pet



net_type=[1,2,1]

net_f=rand_net(net_type,2)



imp=[0]*1
imp[0]=[complex(1),complex(2)]

pout=[0]*1
pout[0]=[complex(1),complex(2)]


print("go")
print()
print(net_f[0])
out=forward_F(net_f,imp,net_type,2,0,1)
net_f=back_ward_prop(net_f, pout, net_type, out,1,2,0,1)

print(net_f[0])


#out=forward_F(net_f,imp,net_type,2,0,1)
#net_f=back_ward_prop(net_f, pout, net_type, out,1,2,0,1)













