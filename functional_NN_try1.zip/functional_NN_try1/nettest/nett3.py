import t2net3 as net
import copy
import numpy as np
loc="/Users/ahauss/Desktop/net1/"

net_type=[5,15,15,15,10,10,10,2]
#the_net=net.get_net("/Users/ahauss/Desktop/net1/",5)


### make random net
the_net=net.make_random_net_with_bies(net_type)



out=net.for_ward_prop2(the_net,[1,2,3,1,5],net_type)



start=[0]*5
start[0]=[1,2,3,1,5]
start[1]=[1,3,-5,1,5]
start[2]=[1,0,0,0,10]
start[3]=[2,4,9,3,2]
start[4]=[1,5,1,1,1]




# needs to be between 0.5 and 1 why i have no idea i might have done something wrong 
# but im unsure i think it has to do with 

def min_F(timp):
	mit=timp[0][0]
	for x in range(len(timp)):
		for y in range(len(timp[0])):
			if mit>=timp[x][y]:
				mit=timp[x][y]
	return mit
def sig(x):# sigmod function 
	return 1/(1+np.exp(-x))


imp=[0]*5
imp[0]=[0.8,0.7]
imp[1]=[0.5,0.3]
imp[2]=[0.2,0.4]
imp[3]=[0.1,0.3]
imp[4]=[0.56,0.53]
# cairfull with hight inputs
#print(sig(10))
#print(sig(11))
# look how close sig 10 and 11 are 

lear_rate=[1,1,1,1,1,1,1]


newnet=net.back_ward_prop(the_net,imp[0],net_type,out,lear_rate)

for x in range(10):
	print()
	for y in range(5):
		pass

		for z in range(40):
			pass
			newnet=net.back_ward_prop(newnet,imp[y],net_type,out,lear_rate)

			out=net.for_ward_prop2(newnet,start[y],net_type)

		print(out[len(out)-1],imp[y])



	print(out[len(out)-1])

net.store_net(loc,newnet)



