import numpy as np
import copy
def sig(x):# sigmod function 
	return 1/(1+np.exp(-x))
def divsig(x):
	return x*(x-1)
def make_random_net_with_bies(net_type):#makes a random net with bies 
	net=[]
	for x in range(len(net_type)-1):
		net.append(rand_m_n(net_type[x+1],net_type[x]+1))

	return net
# net_type [nerons layer 1, nerons layer 2, nerons layer3]
def store_net(loc,net):
	numb=0
	for x in range(len(net)):
		f = open(loc+"L"+str(numb)+".txt", "w")
		for y in range(len(net[x])):
			for z in range(len(net[x][y])):
				f.write(str(net[x][y][z]))
				if z!=(len(net[x][y])-1):
					f.write(",")
			f.write("\n")
		f.close()
		numb+=1

def get_net(loc,numb_layers):
	net=[""]*numb_layers
	for x in range(numb_layers):
		net[x]=get_matrix_numbs(loc,"L"+str(x))
	return net


def get_matrix_numbs(loc,name):
	with open(loc+name+".txt","r") as f:
		array=[""]
		for line in f:
			m=line
			m=m.strip("\n")
			m=m.split(",")
			for x in range(len(m)):
				m[x]=float(m[x])
			array.append(m)
	f.close()
	array.pop(0)
	return array
def rand_m_n(m,n):#makes randome matrix mXn
	mat=[""]*m
	for x in range(m):
		mat[x]=random_mat(n)
	return mat
def random_mat(x):# makes a random value
	return np.random.rand(x)

def numpy_net(net,net_type):
	newnet=[""]*len(net_type)
	for x in range(len(net_type)-1):
		hoy=np.zeros((net_type[x+1],net_type[x]+1))
		#print(hoy)
		for y in range(len(hoy[0])):
			for z in range(len(hoy)):

				hoy[z][y]=net[x][z][y]
		net[x]=hoy
	return net


def for_ward_prop(net,imp,net_type):
	net=numpy_net(net,net_type)
	nerons=[0]*len(net_type)
	for x in range(len(net_type)):
		nerons[x]=np.zeros(net_type[x]+1)
		nerons[x][net_type[x]]=1
	#print(nerons[0])
	for x in range(len(imp)):
		nerons[0][x]=sig(imp[x])
	#print("net")
	#print(net[1])
	#print("")
	for x in range(len(net_type)-1):
		hold=np.dot(net[x],nerons[x])
		for k in range(len(nerons[x+1])-1):
			nerons[x+1][k]=sig(hold[k])

		nerons[x]=np.delete(nerons[x],len(nerons[x])-1)

	return nerons


# what we need to make thsi work with function 
# sigma \/
# dot two vector \/
# store data   \/
# load data   \/
# subtrac two function \/
# add two functions \/
# multiply two function \/
# no devition HAZA \/


# part 2 
#numpy_net X

def dot_matix_with_vector():
	pass


def for_ward_prop2(net,imp,net_type):
	net=numpy_net(net,net_type)
	nerons=[0]*len(net_type)
	
	for x in range(len(net_type)):
		nerons[x]=np.zeros(net_type[x]+1)
		nerons[x][net_type[x]]=1

	#print(nerons[0])
	for x in range(len(imp)):
		nerons[0][x]=sig(imp[x])
	#print("net")
	#print(net[1])
	#print("")
	for x in range(len(net_type)-1):

		hold=np.dot(net[x],nerons[x])
		for k in range(len(nerons[x+1])-1):

			nerons[x+1][k]=sig(hold[k])


	return nerons



def back_ward_prop(net,output,net_type,nerds,lear_rate):
	pet=numpy_net(net,net_type)

	nerons=[0]*len(net_type)
	
	for x in range(len(net_type)):
		nerons[x]=np.zeros(net_type[x]+1)
		nerons[x][net_type[x]]=1
	

	for x in range(len(output)):
		nerons[ len(nerons)-1 ][x]=output[x]

	print()
	delta=[0]*len(nerds)
	for tot in range(len(net_type)-1):
		hold=[0]*len(nerons[ len(nerons)-1-tot] )
		for y in range( len(nerons[ len(nerons)-1-tot] )):
			hold[y]=nerons[ len(nerons)-1-tot][y]-nerds[len(nerons)-1-tot][y]


		delta[tot]=hold
		delta[tot]=np.delete(delta[tot],len(delta[tot])-1)


		holder=nerds[len(nerons)-2-tot]
		print("holder1",holder)

		
		nethold=copy.deepcopy(pet[len(net)-1-tot])

		for x in range(len(nethold)):
			#print(nethold[x])
			#print(delta[tot][x])
			print(holder)
			for y in range(len(nethold[x])):
				pass
				nethold[x]=nethold[x][y]*delta[tot][x]
				nethold[x]=nethold[x][y]*holder[y]


		pet[len(net)-1-tot]=pet[len(net)-1-tot]+1*nethold

	return pet


#loc="/Users/ahauss/Desktop/net1/"

net_type=[1,2,1]
net=make_random_net_with_bies(net_type)



imp=[0]*1
imp[0]=1

output=[1]



lear_rate=[1,1,1,1]
print(net[1])
#out=for_ward_prop2(net,imp,net_type)
#back_ward_prop(net,output,net_type,out,lear_rate)
### make random net
#here=make_random_net_with_bies(net_type)
#store_net(loc,here)
#

#out=for_ward_prop2(net,[1,2,3,1,5],net_type)
#print(out[3])
#print(out[3])

#imp=[0.6,0.55]

#for x in range(1):

#	newnet=back_ward_prop(net,imp,net_type,out)

#	print("")
#
#	out=for_ward_prop2(newnet,[1,2,3,1,5],net_type)
#	print(out[3])

#store_net(loc,newnet)


