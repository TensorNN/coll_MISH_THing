import first_try as net
import copy
import numpy as np
import random
loc="/Users/ahauss/Desktop/net_2mine/"

net_type=[2,3,2]



### make random net
the_net=net.make_random_net_with_bies(net_type)
net.store_net(loc,the_net)
the_net=net.get_net(loc,2)

out=net.for_ward_prop2(the_net,[1,2],net_type)
#print(out[3])
#print(out[3])


start=[0]*5
start[0]=[1,2]
start[1]=[1,3]
start[2]=[1,0]
start[3]=[2,4]
start[4]=[2,5]




# needs to be between 0.5 and 1 why i have no idea i might have done something wrong 
# but im unsure i think it has to do with 

def min_F(timp):
	mit=timp[0][0]
	for x in range(len(timp)):
		for y in range(len(timp[0])):
			if mit>=timp[x][y]:
				mit=timp[x][y]
	return mit
def sig(x):# sigmod function 
	return 1/(1+np.exp(-x))


imp=[0]*5
imp[0]=[3,2]
imp[1]=[1.5,1]
imp[2]=[2.2,2]
imp[3]=[0.9,3]
imp[4]=[0.2,0.53]

# works with any posivie value
#imp=fix_input(timp,back)
# size one less then size of net
lear_rate=[2,2,2,2,2,0.3,0.1]


print("we are here")
newnet=net.back_ward_prop(the_net,imp[0],net_type,out,lear_rate)

print("we are done")
for x in range(10):
	print()
	for y in range(5):
		pass

		for z in range(50):
			pass
			newnet=net.back_ward_prop(newnet,imp[y],net_type,out,lear_rate)


			out=net.for_ward_prop2(newnet,start[y],net_type)
		print(out[len(out)-1],imp[y])



	print(out[len(out)-1])

net.store_net(loc,newnet)

out=[1,2,3,1,5,1]



#a=[[0.04808065,0.58599975,0.41542141,0.23269802,0.90801108,0.43038093,0.69965528,0.15316575,0.95059545,0.40828144,0.12617876],[0.69546405,0.67267442,0.14063677,0.55593853,0.44806494,0.21766228,0.91162769,0.62842137,0.30962532,0.42607342,0.66433947]]

#b=[ 62.51664454,91.62012269,126.84060374,151.45656336,106.65867813,180.76143534,105.80367151,119.73372293,179.9013687,169.64867868,1]

a=[[1,2],[3,4],[3,4]]
b=[1,2]


print(len(a))
a=[[0.85295628,0.30427488,0.64863086,0.51184591],
 [0.62837424,0.33560368,0.9214888 ,0.56443994]]

b=[1.58948761,1.71137635,0.69193271,1]
def random_mat(x):# makes a random value
	return np.random.rand(x)
#print(net.random_mat(10))
#print(net.random_mat2(10))
print(random.random())

