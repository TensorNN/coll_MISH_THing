import t2net as net

loc="/Users/ahauss/Desktop/net1/"

net_type=[5,5,3,5,10,2]
the_net=net.get_net("/Users/ahauss/Desktop/net1/",5)


### make random net
#the_net=net.make_random_net_with_bies(net_type)



out=net.for_ward_prop2(the_net,[1,2,3,1,5],net_type)
#print(out[3])
#print(out[3])


start=[0]*5
start[0]=[1,2,3,1,5]
start[1]=[1,1,1,1,5]
start[2]=[1,0,0,0,5]
start[3]=[2,4,9,3,2]
start[4]=[1,1,1,1,1]

imp=[0]*5


# needs to be between 0.5 and 1 why i have no idea i might have done something wrong 
# but im unsure 

imp[0]=[0.6,0.53]
imp[1]=[0.9,0.71]
imp[2]=[0.55,0.6]
imp[3]=[0.6,0.9]
imp[4]=[0.53,0.53]

# size one less then size of net
lear_rate=[1,1,1,1,1]

newnet=net.back_ward_prop(the_net,imp[0],net_type,out,lear_rate)

for x in range(10):
	print()
	for y in range(5):
		pass

		for z in range(50):
			pass
			newnet=net.back_ward_prop(newnet,imp[y],net_type,out,lear_rate)


			out=net.for_ward_prop2(newnet,start[y],net_type)
		print(out[5],imp[y])



	print(out[5])

net.store_net(loc,newnet)



