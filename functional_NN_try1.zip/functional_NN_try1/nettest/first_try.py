import numpy as np
import copy
import random
def sig(x):# sigmod function 
	return 1/(1+np.exp(-x))

def sig_vec(x):
	out=[0]*len(x)
	for y in range(len(x)):
		out[y]=1/(1+np.exp(-x[y]))
	return out

def divsig(x):
	return x*(x-1)

def make_random_net_with_bies(net_type):#makes a random net with bies 
	net=[]
	for x in range(len(net_type)-1):
		net.append(rand_m_n(net_type[x+1],net_type[x]+1))
	return net
# net_type [nerons layer 1, nerons layer 2, nerons layer3]
def store_net(loc,net):
	numb=0
	for x in range(len(net)):
		f = open(loc+"L"+str(numb)+".txt", "w")
		for y in range(len(net[x])):
			for z in range(len(net[x][y])):
				f.write(str(net[x][y][z]))
				if z!=(len(net[x][y])-1):
					f.write(",")
			f.write("\n")
		f.close()
		numb+=1
def get_net(loc,numb_layers):
	net=[""]*numb_layers
	for x in range(numb_layers):
		net[x]=get_matrix_numbs(loc,"L"+str(x))
	return net


def get_matrix_numbs(loc,name):
	with open(loc+name+".txt","r") as f:
		array=[""]
		for line in f:
			m=line
			m=m.strip("\n")
			m=m.split(",")
			for x in range(len(m)):
				m[x]=float(m[x])
			array.append(m)
	f.close()
	array.pop(0)
	return array

def rand_m_n(m,n):#makes randome matrix mXn
	mat=[""]*m
	for x in range(m):
		mat[x]=random_mat(n)
	return mat

def random_mat(x):# makes a random value
	out=[0]*x
	for y in range(x):
		out[y]=random.random()

	#convert to numpy array 
	out2=zeros_F(x)
	for y in range(x):
		out2[y]=out[y]

	return out2



def numpy_net(net,net_type):
	newnet=[""]*len(net_type)
	for x in range(len(net_type)-1):
		hoy=zeros_f_F(net_type[x+1],net_type[x]+1)
		#print(hoy)
		for y in range(len(hoy[0])):
			for z in range(len(hoy)):

				hoy[z][y]=net[x][z][y]
		net[x]=hoy
	return net








def for_ward_prop2(net,imp,net_type):
	net=numpy_net(net,net_type)
	nerons=[0]*len(net_type)
	for x in range(len(net_type)):
		nerons[x]=zeros_F(net_type[x]+1)
		nerons[x][net_type[x]]=1
	

	#print(nerons[0])
	for x in range(len(imp)):
		nerons[0][x]=imp[x]


	#print("net")
	#print(net[1])
	#print("")
	for x in range(len(net_type)-1):
		#print("one")
		#print(net[x])
		#print("next")
		#print(nerons[x])
		#print("another")
		#print()
		#print("ans")
		#print(net[x])
		#print(len(net[x]))
		#print(nerons[x])
		#print(len(nerons[x]))
		hold=mydot(net[x],nerons[x])


		#print(hold)
		#print()
		#print()
		#print("done")

		for k in range(len(nerons[x+1])-1):

			nerons[x+1][k]=hold[k]

		

	return nerons



def back_ward_prop(net,output,net_type,nerds,lear_rate):
	pet=numpy_net(net,net_type)

	nerons=[0]*len(net_type)
	
	for x in range(len(net_type)):
		nerons[x]=zeros_F(net_type[x]+1)
		nerons[x][net_type[x]]=1
	

	for x in range(len(output)):
		nerons[ len(nerons)-1 ][x]=output[x]

	for tot in range(len(net_type)-1):
		delta=subtractvec( sig_vec( nerons[ len(nerons)-1-tot] ), sig_vec(nerds[len(nerons)-1-tot]) )
		delta.pop(len(delta)-1)

		holder=sig_vec(nerds[len(nerons)-2-tot])

		
		nethold=copy.deepcopy(pet[len(net)-1-tot])

		for x in range(len(nethold)):
			#print("we are")
			#print(delta[tot][x])
			#print(nethold[x])
			#print("here")
			nethold[x]=vector_mult_by_consent(nethold[x],delta[x])# i think i put this in the right place 
			#print("we are")
			#print(nethold[x])
			nethold[x]=vector_mult(nethold[x],holder)
			
			#print()
			#print(holder)
			#print()
			#print(nethold[x])
			#print("here")

		pet[len(net)-1-tot]=matrixadd( pet[len(net)-1-tot], matrix_mult_by_consent(   nethold, lear_rate[tot] )        )

	return pet


def zeros_F(val):

	return [0]*val

def zeros_Fnp(val):

	return np.zeros(val)
#loc="/Users/ahauss/Desktop/net1/"

def matrixadd(matix1,matix2):
	out=[0]*len(matix1)
	for y in range(len(matix1)):
		out[y]=[0]*len(matix1[0])
	for x in range(len(matix1)):
		for y in range(len(matix2[0])):
			out[x][y]=matix2[x][y]+matix1[x][y]
	return out


def subtractvec(vec1,vec2):
	out=[0]*len(vec1)
	for x in range(len(vec1)):
		out[x]=vec1[x]-vec2[x]
	return out


def matrix_mult_by_consent(matix,conset):

	out=[0]*len(matix)
	for y in range(len(matix)):
		out[y]=[0]*len(matix[0])
	for x in range(len(matix)):
		for y in range(len(matix[0])):
			out[x][y]=matix[x][y]*conset
	return out

def vector_mult(vec1,vec2):
	out=[0]*len(vec1)
	for x in range(len(vec1)):
		out[x]=vec1[x]*vec2[x]
	return out

def zeros_f_F(one,two):
	out=[0]*one
	for x in range(one):
		out[x]=[0]*two
	return out

def vector_mult_by_consent(vec1,conset):
	out=[0]*len(vec1)
	for x in range(len(vec1)):
		out[x]=vec1[x]*conset
	return out

def numpydot(net,nerons):
	print("we are in")
	return np.dot(net,nerons)


def mydot(a,b):
	out=[0]*len(a)


	try: 
		len(b[0])
		for x in range(len(a)):
			out[x]=[0]*len(b[x])

		for x in range( len(a) ) :
			for y in range( len(a[0]) ):
				out[x][y]
				for z in range( len(a[0]) ):
					out[x][y]+=a[x][z]*b[z][y]
		return out

	except:
		for x in range(len(a)):
			for y in range(len(b)):
				#print(x,y)
				out[x]+=a[x][y]*b[y]
		return out


#net_type=[5,3,5,2]
#net=get_net("/Users/ahauss/Desktop/net1/",3)


### make random net
#here=make_random_net_with_bies(net_type)
#store_net(loc,here)
#

#out=for_ward_prop2(net,[1,2,3,1,5],net_type)
#print(out[3])
#print(out[3])

#imp=[0.6,0.55]

#for x in range(1):

#	newnet=back_ward_prop(net,imp,net_type,out)

#	print("")
#
#	out=for_ward_prop2(newnet,[1,2,3,1,5],net_type)
#	print(out[3])

#store_net(loc,newnet)


